﻿namespace W05_Cat_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_create = new System.Windows.Forms.TextBox();
            this.btn_create = new System.Windows.Forms.Button();
            this.tb_remove = new System.Windows.Forms.TextBox();
            this.btn_remove = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tb_create
            // 
            this.tb_create.Location = new System.Drawing.Point(594, 48);
            this.tb_create.Name = "tb_create";
            this.tb_create.Size = new System.Drawing.Size(100, 31);
            this.tb_create.TabIndex = 0;
            // 
            // btn_create
            // 
            this.btn_create.Location = new System.Drawing.Point(594, 102);
            this.btn_create.Name = "btn_create";
            this.btn_create.Size = new System.Drawing.Size(122, 40);
            this.btn_create.TabIndex = 1;
            this.btn_create.Text = "Create";
            this.btn_create.UseVisualStyleBackColor = true;
            this.btn_create.Click += new System.EventHandler(this.btn_create_Click);
            // 
            // tb_remove
            // 
            this.tb_remove.Location = new System.Drawing.Point(594, 177);
            this.tb_remove.Name = "tb_remove";
            this.tb_remove.Size = new System.Drawing.Size(100, 31);
            this.tb_remove.TabIndex = 2;
            // 
            // btn_remove
            // 
            this.btn_remove.Location = new System.Drawing.Point(594, 225);
            this.btn_remove.Name = "btn_remove";
            this.btn_remove.Size = new System.Drawing.Size(110, 47);
            this.btn_remove.TabIndex = 3;
            this.btn_remove.Text = "Remove";
            this.btn_remove.UseVisualStyleBackColor = true;
            this.btn_remove.Click += new System.EventHandler(this.btn_remove_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(731, 898);
            this.Controls.Add(this.btn_remove);
            this.Controls.Add(this.tb_remove);
            this.Controls.Add(this.btn_create);
            this.Controls.Add(this.tb_create);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb_create;
        private System.Windows.Forms.Button btn_create;
        private System.Windows.Forms.TextBox tb_remove;
        private System.Windows.Forms.Button btn_remove;
    }
}

