﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace W05_Cat_2
{
    public partial class Form1 : Form
    {
        List<Button> btn2 = new List<Button>(); // list of buttons

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_create_Click(object sender, EventArgs e)
        {
            //cara bikin button tanpa drag and drop, supaya button keluar sendiri
            for (int i = 0; i < btn2.Count; i++)
            {
                this.Controls.Remove(btn2[i]); 
            }
            btn2.Clear();

            for (int i = 0; i < Convert.ToInt16(tb_create.Text); i++)
            {
                Button b = new Button();
                b.Name = "Uhuy Ke " + i;
                b.Tag = "Button ke " + (i + 1); // tag ga keliatan, isinya

                b.Text = "Button" + i;
                b.Size = new Size(150, 30);
                b.Location = new Point(30, 30 + 20 * i);
                b.BackColor = Color.Cyan;
                b.ForeColor = Color.Red;

                b.Click += new EventHandler(sayaClick); //bikin event baru dengan dicoding

                this.Controls.Add(b);
                btn2.Add(b);
            }
        }

        private void btn_remove_Click(object sender, EventArgs e)
        {
            this.Controls.Remove(btn2[Convert.ToInt16(tb_remove.Text)]);
        }

        private void sayaClick(object sender, EventArgs e)  //event baru yg dibikin
        {
            Button sebuahTombol = (Button)sender;  // dimana sebuahTombol isinya adalah sendernya yang diubah mjd sebuah button
            sebuahTombol.Text = "Aku bingung";

            MessageBox.Show(sebuahTombol.Name.ToString());
        }

    }
}
